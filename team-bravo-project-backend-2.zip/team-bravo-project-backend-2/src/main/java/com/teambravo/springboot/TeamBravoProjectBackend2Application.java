package com.teambravo.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamBravoProjectBackend2Application {

	public static void main(String[] args) {
		SpringApplication.run(TeamBravoProjectBackend2Application.class, args);
	}

}
